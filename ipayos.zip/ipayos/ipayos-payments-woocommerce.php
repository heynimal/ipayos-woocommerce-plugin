<?php
/**
 * Plugin Name: IpayOs Payments Gateway
 * Description: Local Payments Gateway for mobile.
 * Version: 0.1.0
 * License URL: vkajamugan@yazhii.net
 * text-domain: ipayos-payments-woo
 * Class WC_Gateway_ipayos file.
 *
 * @package WooCommerce\IpayOs
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) return;

add_action( 'plugins_loaded', 'ipayos_payment_init', 11 );
add_filter( 'woocommerce_currencies', 'techiepress_add_ugx_currencies' );
add_filter( 'woocommerce_currency_symbol', 'techiepress_add_ugx_currencies_symbol', 10, 2 );
add_filter( 'woocommerce_payment_gateways', 'add_to_woo_ipayos_payment_gateway');
add_action( 'woocommerce_thankyou', 'zeninv_redir_based_on_payment_method' );



function zeninv_redir_based_on_payment_method(){

/* do nothing if we are not on the appropriate page */
if( !is_wc_endpoint_url( 'order-received' ) || empty( $_GET['key'] ) ) {
return;
}  
$order_id = wc_get_order_id_by_order_key( $_GET['key'] );
$order = wc_get_order( $order_id );


if( 'ipay-os_payment' == $order->get_payment_method() ) { /* WC 3.0+ */
wp_redirect( 'http://localhost/yazhii-ncc-client/' );
exit;
}
}


function ipayos_payment_init() {
    if( class_exists( 'WC_Payment_Gateway' ) ) {
		require_once plugin_dir_path( __FILE__ ) . '/includes/class-wc-payment-gateway-ipayos.php';
		require_once plugin_dir_path( __FILE__ ) . '/includes/ipayos-order-statuses.php';
	}
}

function add_to_woo_ipayos_payment_gateway( $gateways ) {
    $gateways[] = 'WC_Gateway_IpayOs';
    return $gateways;
}

function techiepress_add_ugx_currencies( $currencies ) {
	$currencies['UGX'] = __( 'Ugandan Shillings', 'ipayos-payments-woo' );
	return $currencies;
}

function techiepress_add_ugx_currencies_symbol( $currency_symbol, $currency ) {
	switch ( $currency ) {
		case 'UGX': 
			$currency_symbol = 'UGX'; 
		break;
	}
	return $currency_symbol;
}


